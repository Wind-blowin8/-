import matplotlib.pyplot as plt # 导入matplotlib的库
import numpy as np # 导入numpy的包
from sklearn.cluster import KMeans # 引入KMeans模块
from sklearn import datasets #导入数据集
from sklearn import metrics # 调用评价指标
iris = datasets.load_iris()     #导入鸢尾花数据集
X = iris.data[:, :4]        #取特征空间中的4个维度
print(X.shape)  #打印出X的尺寸大小
#绘制数据分布图
plt.figure() # 创建图像
plt.subplot(2, 1, 1) # subplot创建单个子图，单个字图中包含4个区域，相应区域在左上角。
plt.scatter(X[:, 0], X[:, 1], c="red", marker='o', label='datas') # 画散点图
plt.xlabel('datas') # 设置X轴的标签为datas
plt.legend(loc=2) # 设置图标
#DBSCAN算法
print("===DBSCAN聚类===")
from sklearn.cluster import DBSCAN # 引入DBSCAN模块
from sklearn import metrics # 调用评价指标
dbscan = DBSCAN(eps=0.43, min_samples=10).fit(X) #导入DBSCAN模块进行训练
label_pred = dbscan.labels_  # labels为每个数据的簇标签
plt.subplot(2, 1, 2) # 创建单个子图，单个子图中包含4个区域，相应的区域在左下角。
x0 = X[label_pred == 0] # 获取聚类标签等于0的话，则赋值给x0
x1 = X[label_pred == 1] # 获取聚类标签等于1的话，则赋值给x1
x2 = X[label_pred == 2] # 获取聚类标签等于2的话，则赋值给x2
plt.scatter(x0[:, 0], x0[:, 1], c="red", marker='o', label='label0') # 画label0的散点图
plt.scatter(x1[:, 0], x1[:, 1], c="green", marker='*', label='label1') # 画label1的散点图
plt.scatter(x2[:, 0], x2[:, 1], c="blue", marker='+', label='label2') # 画label2的散点图
plt.xlabel('DBSCAN')# 设置X轴的标签为DBSCAN
plt.legend(loc=2)# 设置图标在左上角
score = metrics.silhouette_score(X, label_pred, metric="euclidean")# 使用轮廓系数
print(score)# 打印出轮廓系数
plt.show()

